# -*- coding: utf-8 -*-

from odoo import models, fields, api
from elasticsearch import Elasticsearch

class universitéClasse(models.Model):
    _name = 'universite.classes'
    _rec_name = 'nom_classe'

    code_classe = fields.Integer()
    nom_classe = fields.Char('Classe')
    filiere_id = fields.Many2one(comodel_name='universite.filieres', string='Filière')
    niveau_id = fields.Many2one(comodel_name='universite.niveau', string='Niveau',)

    def create_classe_index(self):
        # Configurer la connexion à Elasticsearch
        es = Elasticsearch(['localhost:9200'])
        # Vérifier si l'index existe
        if not es.indices.exists(index='classe'):
            # Définir le mapping pour les champs indexés
            mapping = {
                'properties': {
                    'code_classe': {'type': 'integer'},
                    'nom_classe': {'type': 'text'},
                }
            }
            # Créer l'index avec le mapping
            es.indices.create(index='classe', body={'mappings': mapping})

    @api.model_create_multi
    @api.model
    def create(self, vals_list):
        res = super(universitéClasse, self).create(vals_list)
        # Envoyer les données à Elasticsearch
        es = Elasticsearch(['localhost:9200'])
        for record in res:
            es.index(index='classe', body={
                'code_classe': record.code_classe,
                'nom_classe': record.nom_classe,
            }, id=record.id)
        return res

    def write(self, vals):
        res = super(universitéClasse, self).write(vals)
        # Envoyer les données à Elasticsearch
        es = Elasticsearch(['localhost:9200'])
        for record in self:
            es.index(index='classe', body={
                'code_classe': record.code_filiere,
                'nom_classe': record.nom_classe,
            }, id=record.id)
        return res