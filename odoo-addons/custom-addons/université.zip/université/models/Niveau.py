# -*- coding: utf-8 -*-

from odoo import models, fields, api


class universitéNiveau(models.Model):
    _name = 'universite.niveau'
    _rec_name = 'niveaux'

    niveaux = fields.Selection([('licence 1','Licence 1'),('licence 2','Licence 2'),('licence 3','Licence 3'),('master 1','Master 1'),('master 2','Master 2')])