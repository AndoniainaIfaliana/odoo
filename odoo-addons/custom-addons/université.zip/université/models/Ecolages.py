# -*- coding: utf-8 -*-

from odoo import models, fields, api


class université(models.Model):
    _name = 'universite.ecolages'
    
    prix_premier_tranche = fields.Integer('Premier tranche')
    date_payement_1e_t = fields.Date('Date payement')
    status_payement_1e_t = fields.Selection([('non payé','Non payé'),('payé','Payé')], string='Status')
    prix_deuxieme_tranche = fields.Integer('Deuxième tranche')
    date_payement_2e_t = fields.Date('Date payement')
    status_payement_2e_t = fields.Selection([('non payé','Non payé'),('payé','Payé')], string='Status')
    prix_troisieme_tranche = fields.Integer('Troisième tranche')
    date_payement_3e_t = fields.Date('Date payement')
    status_payement_3e_t = fields.Selection([('non payé','Non payé'),('payé','Payé')], string='Status')
    etudiant_id = fields.Many2one(comodel_name='universite.etudiants', string='Etudiants')
    