# -*- coding: utf-8 -*-

from . import Classes
from . import Prof
from . import Etudiants
from . import Filieres
from . import Matieres
from . import Ecolages
from . import Droit_inscription
from . import Niveau